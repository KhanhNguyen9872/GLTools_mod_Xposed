# Integración Shizuku / ShizukuPlus

> ⚠️ **Advertencia:** Shizuku otorga privilegios de shell ADB a apps normales. Aunque no requiere root, las operaciones realizadas con esos privilegios pueden afectar la estabilidad del sistema si se usan incorrectamente.

## Propósito

Proporcionar una capa de abstracción para operaciones de sistema que requieren privilegios elevados pero no root completo:
- Activar/desactivar capas GLES de depuración.
- Instalar APKs parcheados vía `pm install`.
- Modificar settings globales relacionados con GPU debugging.

## Alcance

Este código usa la API estándar de Shizuku (`rikka.shizuku`), compatible tanto con Shizuku original como con ShizukuPlus. No utiliza las APIs exclusivas de ShizukuPlus porque exceden el alcance de este proyecto.

### [Añad] Qué es ShizukuPlus y por qué sus APIs exclusivas quedan fuera de alcance

ShizukuPlus (`thejaustin/ShizukuPlus`) es un fork activo de Shizuku que añade un conjunto de "Plus APIs" con privilegios más amplios que los de Shizuku original. Documentarlas ayuda a entender la frontera que este proyecto no cruza:

| API exclusiva de Plus | Qué hace | Por qué no se usa aquí |
|---|---|---|
| Privileged Storage Proxy | Acceso autenticado a rutas restringidas como `/data/data/` o `/data/app/` | Este proyecto solo necesita `pm install` y settings globales, no acceso arbitrario a datos de otras apps |
| SU Bridge | Sustituto del binario `su` respaldado por Shizuku, para apps que esperan un entorno con root | Va más allá de "sin root" — introducir un puente de root indirecto no encaja con el alcance declarado del proyecto (privilegios elevados vía Shizuku, no root) |
| AVF (Virtual Machine) Manager | Gestión de máquinas virtuales Linux/Microdroid aisladas | Sin relación con el objetivo (revivir GLTools offline) |
| Device Spoofing (Identity Bridge) | Suplanta identidades de hardware de otros dispositivos para eludir restricciones específicas de dispositivo | Es, por diseño, una herramienta de elusión — incompatible con el principio de no tocar verificación/restricciones (regla 21 del Tratado) |
| Intelligence Bridge / AICore+ Automation Bridge | Proxy privilegiado de accesibilidad para automatización asistida por IA, con simulación de toques | Sin relación con el objetivo del proyecto |

La API estándar (`rikka.shizuku`) que sí se usa en `ShizukuIntegration.java` es idéntica en ambos proyectos — ShizukuPlus mantiene compatibilidad total con las apps que solo consumen la API base. Por eso el código funciona igual con Shizuku original o con ShizukuPlus instalado, sin depender de ninguna de sus funciones exclusivas.

*Fuente: repositorio `thejaustin/ShizukuPlus`, verificado al 30 de julio de 2026.*

## Requisitos

- Shizuku o ShizukuPlus instalado y activo en el dispositivo.
- Permiso concedido a esta app en Shizuku Manager.
- Para capas GLES: la app objetivo debe tener `android:debuggable="true"`.

## Limitaciones

- No permite escritura en `/system` ni modificación de particiones protegidas.
- Las capas GLES solo funcionan en apps debuggables sin root; con root, funcionan en cualquier app.
- `pm install` requiere que el APK esté en almacenamiento accesible.

## Referencia

- Shizuku original: https://github.com/RikkaApps/Shizuku (Apache 2.0)
- ShizukuPlus: https://github.com/thejaustin/ShizukuPlus (Apache 2.0)
- API de Shizuku: https://github.com/RikkaApps/Shizuku-API
