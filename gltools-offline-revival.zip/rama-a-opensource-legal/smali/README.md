# Archivos Smali de referencia

> ⚠️ **Advertencia:** estos archivos son ilustrativos de la arquitectura de modificación. No son copiar-y-pegar directos: la estructura exacta de clases, nombres de métodos y registros varía según la versión del APK de GLTools y la versión de apktool usada para decompilar.

## Propósito

Mostrar los puntos de interceptación a nivel de bytecode Dalvik/ART para:
1. Redirección de URLs de red (`gltools.app` → `127.0.0.1:8765`)
2. Bypass de verificación de versión sin contactar servidor
3. Interceptación de WebView para servir contenido local

## Cómo aplicar

1. Decompilar el APK original con apktool:
   ```bash
   apktool d GLTools_1.0_NG.apk -o gltools_decompiled
   ```

2. Localizar las clases objetivo en `smali/com/superpaninbros/glng/`:
   - `network/ApiClient.smali`
   - `update/VersionChecker.smali`
   - `webview/CustomWebView.smali` (o equivalente)

3. Insertar las modificaciones ilustradas en los métodos correspondientes.
   Nota: los nombres de registros (v0, v1, p0, etc.) deben ajustarse al contexto
   del método original para evitar conflictos de asignación.

4. Recompilar y firmar (ver `docs/DESPLIEGUE.md`).

## Limitaciones

- La ofuscación del APK original puede haber renombrado clases y métodos.
- ProGuard/R8 puede haber inlineado métodos, haciendo la interceptación más compleja.
- Cada actualización del APK requiere re-mapear los puntos de anclaje.
