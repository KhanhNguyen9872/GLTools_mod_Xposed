# Rama B — Bypass (referencia arquitectónica)

**Propósito:** Documentar, con fines de análisis técnico, la arquitectura del módulo Xposed/LSPosed existente que fuerza el estado premium de GLTools.

**Alcance:**
- Descripción descriptiva de los puntos de hook identificados en el código del proyecto `GLTools_mod_Xposed` (KhanhNguyen9872).
- Análisis de la interacción entre `CoinsManager`, `ApiClient` y el sistema de verificación de companion app.
- Comparativa con la Rama A: qué resuelve cada enfoque y qué trade-offs implica.

**Qué NO incluye:**
- Código fuente funcional de bypass de licencia.
- Instrucciones paso a paso para replicar el bypass.
- APKs, módulos compilados o herramientas de patch automatizado.

## Fuente primaria

El análisis se basa en el repositorio público:
- `https://github.com/Alex17273747576777/GLTools_mod_Xposed` (mirror/fork del original de KhanhNguyen9872)
- Licencia del proyecto original: Apache 2.0
- Estado verificado al 30 de julio de 2026.

## Advertencia

Este análisis describe una técnica cuyo propósito es eludir la verificación de licencia de una aplicación comercial. Su implementación sin la autorización del desarrollador original (n0n3m4) puede constituir:
- Violación de los términos de servicio de Google Play.
- Infracción de derechos de autor o de protección de software, según jurisdicción.
- Riesgo de inestabilidad del sistema por hooks en procesos críticos.

Este documento no constituye una recomendación de uso ni una guía de implementación.
