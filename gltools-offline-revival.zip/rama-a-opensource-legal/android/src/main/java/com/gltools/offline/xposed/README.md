# Módulo Xposed/LSPosed — Red Neutral

> ⚠️ **Advertencia:** este módulo requiere LSPosed framework instalado y activo. Modificar el comportamiento de apps mediante hooks conlleva riesgo de inestabilidad. Realizar backup antes de activar.

## Propósito

Interceptar peticiones de red de GLTools (`com.superpaninbros.glng`) y redirigirlas a un servidor mock local (`127.0.0.1:8765`), evitando crashes por servidor caído (`gltools.app`).

## Qué NO hace

- No modifica `CoinsManager.isPremium()` ni ningún método de verificación de compra.
- No inyecta estado de licencia falso.
- No oculta botones de UI relacionados con premium.

## Requisitos

- Android 9+ con LSPosed (Zygisk o Riru).
- GLTools instalado (`com.superpaninbros.glng`).
- Servidor mock en ejecución (ver `android/.../server/GLToolsMockServer.java`).

## Instalación

1. Compilar el módulo como APK (ver `gradle/` para build).
2. Instalar el APK del módulo.
3. Abrir LSPosed Manager → Módulos → activar GLToolsNetworkModule.
4. Establecer scope: `com.superpaninbros.glng`.
5. Forzar detención de GLTools y reiniciar.

## Hooks implementados

| Hook | Clase objetivo | Efecto |
|---|---|---|
| URL redirect | `java.net.URL` | Redirige `gltools.app` → `127.0.0.1:8765` |
| Version bypass | `VersionChecker.checkVersion()` | Inyecta respuesta segura sin force-update |
| Companion silencer | `ApiClient.fetchCompanionStatus()` | Devuelve null para evitar crash |

## Vía de recuperación

Si GLTools se vuelve inestable:
1. Desactivar el módulo en LSPosed Manager.
2. Forzar detención de GLTools.
3. Si persiste, desinstalar el módulo y reiniciar el dispositivo.
