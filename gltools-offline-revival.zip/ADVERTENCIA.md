# Advertencias y marco de uso

> ⚠️ **Advertencia legal:** la ingeniería inversa de software puede estar restringida según jurisdicción. Este repositorio contiene información técnica; la aplicación es responsabilidad de quien la ejecute.
> ⚠️ **Advertencia de seguridad:** la interceptación de OpenGL ES puede causar inestabilidad del sistema gráfico. Realizar backup completo del dispositivo antes de cualquier modificación.
> ⚠️ **Advertencia de estabilidad:** instalación de APKs modificados o módulos de sistema conlleva riesgo de bootloop o pérdida de datos.

## Separación de ramas

Este repositorio se organiza en dos ramas documentales con propósitos distintos:

| Rama | Propósito | Alcance técnico | Estado legal/ético |
|---|---|---|---|
| **A — OpenSource/Legal** | Recuperar funcionalidad de GLTools para dispositivos con licencia ya adquirida, eliminando dependencia de servidores caídos (`gltools.app`) | Mock de endpoints de red no relacionados con licencia; capas GLES para apps debuggables; gestión offline de perfiles y plugins | No modifica verificación de compra; asume estado premium persistido localmente |
| **B — Bypass (referencia)** | Documentación de arquitectura del módulo Xposed existente que fuerza estado premium | Análisis descriptivo de hooks en `CoinsManager` y `ApiClient`; no se incluye código funcional de bypass en este repositorio | Elude verificación de licencia; su uso sin autorización del desarrollador original puede constituir violación de términos de servicio o legislación aplicable |

## Vía de recuperación

Si el sistema gráfico se vuelve inestable tras cualquier modificación:

1. Desinstalar la app modificada.
2. Si se usaron capas GLES de depuración, ejecutar:
   ```bash
   adb shell settings delete global enable_gpu_debug_layers
   adb shell settings delete global gpu_debug_app
   adb shell settings delete global gpu_debug_layers_gles
   adb shell settings delete global gpu_debug_layer_app
   ```
3. Si se instaló un módulo de sistema (solo con root), flashear el ZIP de desinstalación desde recovery.
4. Reiniciar el dispositivo.

## Nota sobre el estado de verificación

La información de este repositorio se basa en:
- El APK original de GLTools (`com.superpaninbros.glng`) y su documentación histórica en XDA-Developers (fuente secundaria, no verificada directamente en este momento).
- La documentación oficial de Android sobre GLES Layers (`source.android.com`), verificada al 30 de julio de 2026.
- El repositorio `GLTools_mod_Xposed` de KhanhNguyen9872 (GitHub), verificado como existente al 30 de julio de 2026; su código no se reproduce aquí.

Las políticas de seguridad de Android pueden cambiar en versiones futuras. Los snippets de código son ilustrativos de arquitectura, no garantías de funcionamiento en todos los dispositivos.
