# Índice de archivos — GLTools Offline Revival

## Raíz
- `ADVERTENCIA.md` — Marco legal, separación de ramas, vías de recuperación
- `README.md` — Propósito, alcance, estructura y estado de dependencias

## Rama A — OpenSource/Legal

### Documentación
- `rama-a-opensource-legal/README.md` — Propósito y alcance de la rama A
- `rama-a-opensource-legal/docs/DIAGNOSTICO.md` — Verificación de estado de licencia local
- `rama-a-opensource-legal/docs/DESPLIEGUE.md` — Opciones de despliegue (APK, LSPatch, Shizuku)
- `rama-a-opensource-legal/docs/REVERSION.md` — Troubleshooting y vías de recuperación

### Código fuente Java
- `android/src/main/java/com/gltools/offline/server/GLToolsMockServer.java` — Servidor HTTP embebido (NanoHTTPD)
- `android/src/main/java/com/gltools/offline/server/GLToolsMockService.java` — Servicio Android para mantener el servidor vivo
- `android/src/main/java/com/gltools/offline/db/ProfileDatabase.java` — Base de datos SQLite de perfiles offline
- `android/src/main/java/com/gltools/offline/plugin/OfflinePluginLoader.java` — Gestor de plugins desde assets
- `android/src/main/java/com/gltools/offline/config/LayerConfig.java` — Gestor de configuración INI para capa GLES
- `android/src/main/java/com/gltools/offline/diagnostic/LicenseDiagnostics.java` — Utilidad de diagnóstico de licencia local

### Código fuente C++ / NDK
- `android/src/main/cpp/gltools_layer.cpp` — Capa GLES de depuración (OpenGL ES Layer API)
- `android/src/main/cpp/CMakeLists.txt` — Script de compilación para Android NDK

### [Añad] Integración Shizuku
- `android/src/main/java/com/gltools/offline/shizuku/README.md` — Propósito, alcance y comparativa Shizuku vs. ShizukuPlus
- `android/src/main/java/com/gltools/offline/shizuku/ShizukuIntegration.java` — Capas GLES, settings globales e instalación de APK vía Shizuku/ShizukuPlus (API estándar únicamente)

### [Añad] Módulo Xposed/LSPosed de red neutral
- `android/src/main/java/com/gltools/offline/xposed/README.md` — Propósito, hooks implementados y qué NO hace este módulo
- `android/src/main/java/com/gltools/offline/xposed/GLToolsNetworkModule.java` — Redirección de red y bypass del force-update; no toca `CoinsManager` ni verificación de compra

### [Añad] Referencia Smali
- `smali/README.md` — Cómo aplicar los parches ilustrativos y sus limitaciones
- `smali/ApiClientRedirect.smali` — Redirección de `gltools.app` a servidor mock local
- `smali/VersionCheckerBypass.smali` — Versión embebida para evitar force-update
- `smali/WebViewInterceptor.smali` — Servir ayuda local cuando el WebView interno intenta cargar `gltools.app`

### Configuración
- `android/AndroidManifest.xml` — Plantilla con declaración del servicio mock
- `gradle/build.gradle`, `gradle/settings.gradle`, `gradle/gradle-wrapper.properties`, `gradle/AndroidManifest.xml` — Build del módulo Xposed/LSPosed
- `gradle/res/values/xposed_scope.xml` — Declaración de scope (`com.superpaninbros.glng`)

### Scripts
- `scripts/build_apk.sh` — Automatización de build APK parcheado
- `scripts/diagnose.sh` — Diagnóstico remoto vía ADB

## Rama B — Bypass (referencia)
- `rama-b-bypass-referencia/README.md` — Propósito y alcance de la rama B
- `rama-b-bypass-referencia/ANALISIS_ARQUITECTURA.md` — Descripción arquitectónica del módulo Xposed existente, sin código funcional

## Notas de verificación
- Fecha de verificación: 30 de julio de 2026
- Fuente primaria del código funcional: documento `GLTools_Offline_Revival_Plan_v2.md`
- Fuente secundaria de la Rama B: repositorio GitHub `Alex17273747576777/GLTools_mod_Xposed`
