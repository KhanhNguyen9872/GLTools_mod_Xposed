# Análisis arquitectónico del bypass existente

> ⚠️ **Advertencia:** este documento es descriptivo, no instructivo. Describe la arquitectura de un módulo Xposed de terceros con fines de comprensión técnica. No incluye código funcional de bypass ni guías de implementación.

## Fuente

- Repositorio: `https://github.com/Alex17273747576777/GLTools_mod_Xposed`
- Autor original: Nguyễn Văn Khánh (KhanhNguyen9872)
- Licencia del proyecto original: Apache 2.0
- Estado verificado al 30 de julio de 2026.

## Componentes identificados

### 1. Hook de `CoinsManager`

El módulo intercepta métodos relacionados con la verificación de estado premium dentro de la clase `CoinsManager` de GLTools. La técnica documentada (según el README del proyecto) fuerza el retorno de `isPremium()` a `true` de forma incondicional.

**Implicación técnica:** esto anula cualquier verificación local o remota del estado de compra, independientemente de si el usuario adquirió la licencia o no. El artefacto no distingue entre usuarios legítimos y no legítimos.

### 2. Hook de `ApiClient`

Similar a la Rama A, el módulo intercepta las conexiones salientes a `gltools.app`. Sin embargo, en lugar de redirigir a un servidor local neutro, inyecta respuestas que simulan un servidor funcional, incluyendo endpoints de premium.

**Diferencia clave con la Rama A:** la Rama A devuelve `{"reachable": false}` para companion y no implementa `/api/premium`. El módulo de bypass implementa una respuesta que confirma activación.

### 3. Ocultación de UI

El módulo fuerza la ocultación del botón "Get companion" en la interfaz de navegación. Esto es un efecto secundario visual del hook de premium, no una modificación de recursos de la app.

### 4. Inyección de WebView

El README menciona interceptación de tráfico WebView interno (feeds de Twitter, páginas de ayuda) para inyectar HTML personalizado. Esto opera a nivel de `CustomWebView` o equivalente dentro del APK de GLTools.

## Comparativa Rama A vs. Rama B

| Aspecto | Rama A (este repositorio) | Rama B (módulo Xposed referenciado) |
|---|---|---|
| **Objetivo declarado** | Recuperar funcionalidad para licencias ya adquiridas | Desbloquear premium incondicionalmente |
| **Tratamiento de licencia** | No se toca; se diagnostica estado local | Se fuerza a `true` vía hook |
| **Servidor mock** | Localhost, neutro, sin endpoint premium | Respuestas hardcodeadas que confirman premium |
| **Requisito de root** | No (APK parcheado) o parcial (LSPatch/Shizuku) | Sí (LSPosed requiere root/Zygisk) |
| **Riesgo legal** | Ingeniería inversa para recuperación funcional | Elusión de protección técnica de software |
| **Riesgo técnico** | Bajo-Medio (APK modificado) | Medio-Alto (hooks en proceso crítico) |

## Por qué este repositorio no implementa la Rama B

1. **Indistinguibilidad:** un parche que fuerza `isPremium() = true` es funcionalmente idéntico para quien pagó y quien no. No hay mecanismo técnico para condicionarlo.
2. **Probablemente innecesario para legítimos:** si el estado de compra está cacheado localmente (ver `rama-a/docs/DIAGNOSTICO.md`), el problema real es el crash por servidor caído, no la ausencia de premium.
3. **Marco ético:** este repositorio opera bajo el principio de no optimizar ni mejorar herramientas cuyo propósito principal sea eludir verificación de licencia (Tratado de la Bandita v12, Parte V, Orden 11).

## Referencias cruzadas

- Para recuperación funcional sin tocar licencia: ver `rama-a-opensource-legal/`.
- Para diagnóstico de estado local: ver `rama-a-opensource-legal/docs/DIAGNOSTICO.md`.
- Para el proyecto original de bypass: consultar directamente el repositorio de KhanhNguyen9872.
