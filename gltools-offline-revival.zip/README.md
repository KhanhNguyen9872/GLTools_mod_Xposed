# GLTools Offline Revival — Repositorio dual

**Propósito:** Proporcionar una ruta de despliegue funcional para GLTools (`com.superpaninbros.glng`) en dispositivos Android 14+, eliminando la dependencia de los servidores `gltools.app` (caídos), con separación explícita entre recuperación funcional para licencias legítimas y análisis arquitectónico de métodos de bypass.

**Alcance:**
- Rama A: código funcional para mock de endpoints de red, capas GLES de depuración, gestión offline de perfiles/plugins, y utilidades de diagnóstico.
- Rama B: análisis descriptivo de la arquitectura de bypass existente, sin código funcional de elusión de licencia.

**Limitación:** La información está verificada al 30 de julio de 2026. No se garantiza compatibilidad con versiones futuras de Android. Los snippets de código requieren adaptación a la versión específica del APK de GLTools que posea el usuario.

---

## Estructura del repositorio

```
gltools-offline-revival/
├── ADVERTENCIA.md          # Marco legal, separación de ramas, vías de recuperación
├── README.md               # Este archivo
├── rama-a-opensource-legal/
│   ├── README.md           # Documentación específica de la rama A
│   ├── android/            # Código fuente Java y C++
│   ├── docs/               # Guías de diagnóstico, despliegue y reversión
│   └── scripts/            # Scripts de build y utilidades ADB
└── rama-b-bypass-referencia/
    ├── README.md           # Documentación específica de la rama B
    └── ANALISIS_ARQUITECTURA.md  # Descripción técnica de hooks sin implementación
```

## Cómo usar este repositorio

1. Leer `ADVERTENCIA.md` antes de cualquier acción.
2. Determinar si tu dispositivo conserva el estado de compra de GLTools localmente (ver `rama-a-opensource-legal/docs/DIAGNOSTICO.md`).
3. Si el estado de compra está presente: seguir la Rama A.
4. Si buscas entender cómo funciona el bypass existente (sin implementarlo): consultar la Rama B.

## Estado de las dependencias externas

| Dependencia | Estado al 30/07/2026 | Nota |
|---|---|---|
| `gltools.app` | Caído | Servidor original de GLTools; motivo de este proyecto |
| LSPatch (GitHub) | Archivado (diciembre 2023) | Soporte para Android 14 teórico, no garantizado |
| Shizuku | Activo (GitHub, mayo 2026) | No permite escritura en `/system` |
| NanoHTTPD | Proyecto existente | Licencia BSD |
| Android GLES Layers | Documentación oficial verificada | Android 10+ |

## Licencia del contenido original

El código de este repositorio (Rama A) se distribuye bajo licencia MIT, salvo donde se indique lo contrario. El análisis de la Rama B es información descriptiva sobre un proyecto de terceros (Apache 2.0, según su propio repositorio).

GLTools es propiedad de su desarrollador original (n0n3m4). Este repositorio no redistribuye el APK original ni sus recursos protegidos.
